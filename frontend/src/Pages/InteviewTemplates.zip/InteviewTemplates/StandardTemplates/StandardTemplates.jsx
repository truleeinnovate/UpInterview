// v1.0.0 - Ashok - removed loading in this
// v1.0.1 - Ashok - changed UI only

import React, { useState, useRef, useMemo, useEffect } from "react";
import StandardTemplateTableView from "./StandardTemplateTableView";
import StandardTemplateKanbanView from "../KanbanView.jsx";
// import Toolbar from "../../../Components/Shared/Toolbar/Toolbar";
import Toolbar from "./StandardTemplatesHeader.jsx";
import { ChevronDown, ChevronUp } from "lucide-react";
import { FilterPopup } from "../../../Components/Shared/FilterPopup/FilterPopup";
import { useInterviewTemplates } from "../../../apiHooks/useInterviewTemplates.js";
import { usePermissions } from "../../../Context/PermissionsContext";
import { useNavigate } from "react-router-dom";

// Error Boundary Component
class ErrorBoundary extends React.Component {
  state = { hasError: false, error: null };

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="p-6 text-red-600">
          <h1>Something went wrong.</h1>
          <p>{this.state.error?.message || "An unexpected error occurred."}</p>
        </div>
      );
    }
    return this.props.children;
  }
}

const StandardTemplates = ({ handleClone }) => {
  const { templatesData, isLoading } = useInterviewTemplates();
  const { effectivePermissions } = usePermissions();
  const navigate = useNavigate();

  // Transform API data to match the expected structure
  const normalizedTemplates = useMemo(() => {
    if (!templatesData || !Array.isArray(templatesData)) return [];

    return templatesData
      .filter((template) => template.type === "standard")
      .map((template) => ({
        _id: template._id || `template-${Math.random()}`,
        title: template.title || template.roundTitle || "Unnamed Template",
        name: template.name || "",
        description: template.description || "No description available",
        rounds: Array.isArray(template.rounds)
          ? template.rounds
          : Array.isArray(template.sequence)
          ? template.sequence
          : [{ roundTitle: "Unknown round" }],
        bestFor: template.bestFor || "General roles",
        format: template.format || "Unknown format",
        type: template.type || "standard",
        status: template.status || "active",
        category: template.category || "Uncategorized",
        createdAt: template.createdAt || new Date().toISOString(),
        updatedAt: template.updatedAt || new Date().toISOString(),
      }));
  }, [templatesData]);

  // Toolbar & Filter state
  const [view, setView] = useState("table");
  const [searchQuery, setSearchQuery] = useState("");
  const [currentPage, setCurrentPage] = useState(0);
  const [isFilterPopupOpen, setFilterPopupOpen] = useState(false);
  const [isFilterActive, setIsFilterActive] = useState(false);
  const filterIconRef = useRef(null);

  // Filter states
  const [selectedStatus, setSelectedStatus] = useState([]);
  const [selectedFormats, setSelectedFormats] = useState([]);
  const [createdDatePreset, setCreatedDatePreset] = useState("");

  // UI states for dropdowns
  const [isStatusOpen, setIsStatusOpen] = useState(false);
  const [isFormatOpen, setIsFormatOpen] = useState(false);
  const [isCreatedDateOpen, setIsCreatedDateOpen] = useState(false);
  // v1.0.1 <----------------------------------------------------------------------
  const [activeTab, setActiveTab] = useState(() => {
    // Initialize from URL on first render
    const params = new URLSearchParams(window.location.search);
    const tabFromUrl = params.get("tab");
    return tabFromUrl === "standard" || tabFromUrl === "custom"
      ? tabFromUrl
      : "standard";
  });

  // Keep URL in sync with tab state
  useEffect(() => {
    console.log("Current active tab:", activeTab);
    const params = new URLSearchParams(window.location.search);

    // Only update URL if it doesn't match the current tab
    if (params.get("tab") !== activeTab) {
      console.log("Updating URL to match active tab:", activeTab);
      params.set("tab", activeTab);
      navigate({ search: params.toString() }, { replace: true });
    }
  }, [activeTab, navigate]);

  // Handle tab change from URL (e.g., browser back/forward)
  useEffect(() => {
    const handlePopState = () => {
      const params = new URLSearchParams(window.location.search);
      const tabFromUrl = params.get("tab");
      console.log("URL changed, tab from URL:", tabFromUrl);

      if (
        tabFromUrl &&
        (tabFromUrl === "standard" || tabFromUrl === "custom")
      ) {
        console.log("Updating active tab from URL:", tabFromUrl);
        setActiveTab(tabFromUrl);
      } else if (!tabFromUrl) {
        // If no tab in URL, set default and update URL
        console.log("No tab in URL, setting to default");
        setActiveTab("standard");
        params.set("tab", "standard");
        navigate({ search: params.toString() }, { replace: true });
      }
    };

    // Listen for URL changes
    window.addEventListener("popstate", handlePopState);

    // Initial check
    handlePopState();

    return () => {
      window.removeEventListener("popstate", handlePopState);
    };
  }, [navigate]);
  // v1.0.1 ---------------------------------------------------------------------->

  // Selected filters state
  const [selectedFilters, setSelectedFilters] = useState({
    status: [],
    formats: [],
    createdDate: "",
  });

  const normalizeSpaces = (str) =>
    str?.toString().replace(/\s+/g, " ").trim().toLowerCase() || "";

  // Status toggle handler
  // Status toggle handler
  const handleStatusToggle = (status) => {
    setSelectedStatus((prev) =>
      prev.includes(status)
        ? prev.filter((s) => s !== status)
        : [...prev, status]
    );
  };

  // Format toggle handler
  const handleFormatToggle = (format) => {
    setSelectedFormats(prev =>
      prev.includes(format)
        ? prev.filter(f => f !== format)
        : [...prev, format]
    );
  };

  // Format options for the filter
  const formatOptions = [
    { label: "Online / Virtual", value: "online" },
    { label: "Face to Face / Onsite", value: "offline" },
    { label: "Hybrid (Online + Onsite)", value: "hybrid" }
  ];

  // Apply filters
  const handleApplyFilters = () => {
    const filters = {
      status: selectedStatus,
      formats: selectedFormats,
      createdDate: createdDatePreset,
    };
    setSelectedFilters(filters);
    setIsFilterActive(selectedStatus.length > 0 || selectedFormats.length > 0 || createdDatePreset !== "");
    setFilterPopupOpen(false);
    setCurrentPage(0);
  };

  // Clear all filters
  const handleClearAll = () => {
    setSelectedStatus([]);
    setSelectedFormats([]);
    setCreatedDatePreset("");
    setSelectedFilters({
      status: [],
      formats: [],
      createdDate: "",
    });
    setIsFilterActive(false);
  };

  // Filtered templates based on search & filters
  const filteredTemplates = useMemo(() => {
    return normalizedTemplates.filter((template) => {
      const normalizedQuery = normalizeSpaces(searchQuery);
      const fieldsToSearch = [template.title, template.status, template.format].filter(Boolean);

      // Search query matching
      const matchesSearchQuery =
        searchQuery === "" ||
        fieldsToSearch.some((field) =>
          normalizeSpaces(field).includes(normalizedQuery)
        );

      // Status filter
      const matchesStatus =
        selectedFilters.status.length === 0 ||
        selectedFilters.status.includes(template.status || "Active");

      // Format filter
      const matchesFormat =
        selectedFilters.formats.length === 0 ||
        (template.format && selectedFilters.formats.includes(template.format));

      // Created date filter
      const matchesCreatedDate = () => {
        if (!selectedFilters.createdDate) return true;
        if (!template.createdAt) return false;
        const daysDiff = Math.floor(
          (new Date() - new Date(template.createdAt)) / (1000 * 60 * 60 * 24)
        );
        switch (selectedFilters.createdDate) {
          case "last7":
            return daysDiff <= 7;
          case "last30":
            return daysDiff <= 30;
          case "last90":
            return daysDiff <= 90;
          default:
            return true;
        }
      };

      return (
        matchesSearchQuery &&
        matchesStatus &&
        matchesFormat &&
        matchesCreatedDate()
      );
    });
  }, [searchQuery, selectedFilters, normalizedTemplates]);

  // Pagination
  const itemsPerPage = 10;
  const totalPages = Math.ceil(filteredTemplates.length / itemsPerPage);
  const paginatedTemplates = filteredTemplates.slice(
    currentPage * itemsPerPage,
    (currentPage + 1) * itemsPerPage
  );

  // Toolbar handlers
  const handlePreviousPage = () => {
    if (currentPage > 0) setCurrentPage((prev) => prev - 1);
  };

  const handleNextPage = () => {
    if (currentPage < totalPages - 1) setCurrentPage((prev) => prev + 1);
  };

  const handleFilterIconClick = () => {
    if (normalizedTemplates.length !== 0) {
      setFilterPopupOpen((prev) => !prev);
    }
  };

  // Filter handler functions are already defined above
  // Removed duplicate function declarations

  const handleView = (template) => {
    if (effectivePermissions.InterviewTemplates?.View) {
      navigate(`/interview-templates/${template._id}`);
    }
  };

  return (
    <>
      <div className="sm:px-4 px-6">
        <Toolbar
          view={view}
          setView={setView}
          searchQuery={searchQuery}
          onSearch={(e) => setSearchQuery(e.target.value)}
          currentPage={currentPage}
          totalPages={totalPages}
          onPrevPage={handlePreviousPage}
          onNextPage={handleNextPage}
          onFilterClick={handleFilterIconClick}
          isFilterActive={isFilterActive}
          isFilterPopupOpen={isFilterPopupOpen}
          dataLength={normalizedTemplates.length}
          searchPlaceholder="Search Interview Templates..."
          filterIconRef={filterIconRef}
          // v1.0.2 <------------------------------------------
          templatesData={paginatedTemplates}
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          // v1.0.2 ------------------------------------------>
        />
        <FilterPopup
          isOpen={isFilterPopupOpen}
          onClose={() => setFilterPopupOpen(false)}
          onApply={handleApplyFilters}
          onClearAll={handleClearAll}
          filterIconRef={filterIconRef}
        >
          <div className="space-y-3 max-h-[60vh] overflow-y-auto pr-2">
            <div>
              <div
                className="flex justify-between items-center cursor-pointer"
                onClick={() => setIsStatusOpen(!isStatusOpen)}
              >
                <span className="font-medium text-gray-700">Status</span>
                {isStatusOpen ? (
                  <ChevronUp className="text-xl text-gray-700" />
                ) : (
                  <ChevronDown className="text-xl text-gray-700" />
                )}
              </div>
              {isStatusOpen && (
                <div className="mt-1 space-y-1 pl-3 max-h-32 overflow-y-auto">
                  {["Active", "Draft", "Archived", "Inactive"].map((status) => (
                    <label key={status} className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        checked={selectedStatus.includes(status)}
                        onChange={() => handleStatusToggle(status)}
                        className="h-4 w-4 rounded accent-custom-blue focus:ring-custom-blue"
                      />
                      <span className="text-sm">{status}</span>
                    </label>
                  ))}
                </div>
              )}
            </div>
            {/* Format Filter */}
            <div className="mt-4">
              <div
                className="flex justify-between items-center cursor-pointer"
                onClick={() => setIsFormatOpen(!isFormatOpen)}
              >
                <span className="font-medium text-gray-700">Format</span>
                {isFormatOpen ? (
                  <ChevronUp className="text-xl text-gray-700" />
                ) : (
                  <ChevronDown className="text-xl text-gray-700" />
                )}
              </div>
              {isFormatOpen && (
                <div className="mt-2 pl-3 space-y-2">
                  {formatOptions.map((format) => (
                    <label key={format.value} className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        checked={selectedFormats.includes(format.value)}
                        onChange={() => handleFormatToggle(format.value)}
                        className="h-4 w-4 rounded accent-custom-blue focus:ring-custom-blue"
                      />
                      <span className="text-sm">{format.label}</span>
                    </label>
                  ))}
                </div>
              )}
            </div>

            {/* Created Date Filter */}
            <div className="mt-4">
              <div
                className="flex justify-between items-center cursor-pointer"
                onClick={() => setIsCreatedDateOpen(!isCreatedDateOpen)}
              >
                <span className="font-medium text-gray-700">Created Date</span>
                {isCreatedDateOpen ? (
                  <ChevronUp className="text-xl text-gray-700" />
                ) : (
                  <ChevronDown className="text-xl text-gray-700" />
                )}
              </div>
              {isCreatedDateOpen && (
                <div className="mt-2 pl-3 space-y-1">
                  {[
                    { value: "", label: "Any time" },
                    { value: "last7", label: "Last 7 days" },
                    { value: "last30", label: "Last 30 days" },
                    { value: "last90", label: "Last 90 days" },
                  ].map((option) => (
                    <label
                      key={option.value}
                      className="flex items-center space-x-2"
                    >
                      <input
                        type="radio"
                        value={option.value}
                        checked={createdDatePreset === option.value}
                        onChange={(e) => setCreatedDatePreset(e.target.value)}
                        className="h-4 w-4 accent-custom-blue focus:ring-custom-blue"
                      />
                      <span className="text-sm">{option.label}</span>
                    </label>
                  ))}
                </div>
              )}
            </div>
          </div>
        </FilterPopup>
      </div>
      <div>
        {view === "table" ? (
          <div className="w-full overflow-x-auto">
            <ErrorBoundary>
              <StandardTemplateTableView
                templatesData={paginatedTemplates}
                handleClone={handleClone}
              />
            </ErrorBoundary>
          </div>
        ) : (
          <div>
            <ErrorBoundary>
              <StandardTemplateKanbanView
                templates={paginatedTemplates}
                loading={isLoading}
                effectivePermissions={effectivePermissions}
                onView={handleView}
                // onEdit={handleEdit}
                handleClone={handleClone}
              />
            </ErrorBoundary>
          </div>
        )}
      </div>
    </>
  );
};

export default StandardTemplates;
